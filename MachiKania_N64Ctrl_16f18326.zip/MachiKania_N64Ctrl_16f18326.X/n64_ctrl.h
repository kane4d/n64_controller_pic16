/* 
 * File:   n64_ctrl.h
 * Author: kane4d
 *
 * Created on September 21, 2018, 9:02 PM
 */

#ifndef N64_CTRL_H
#define	N64_CTRL_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "mcc_generated_files/mcc.h"

#ifdef _16F18446
/* Xpress PIC16F18446
 * Clock: 32MHz
 * N64 Signal: RC0
 * Timer: TMR3 170us
 */

#define N64_LAT N64IO_LAT
#define N64_PORT N64IO_PORT
#define N64_PORT_BANK bank0

#define N64_TMR_Start() {PIR4bits.TMR3IF=0;TMR3_StartTimer();}
#define N64_TMR_Stop() TMR3_StopTimer()
#define N64_TMR_Reload() TMR3_Reload()
#define N64_TMR_HasOverflowOccured() TMR3_HasOverflowOccured()

#define N64_IO_ISR_ClearFlag()      IOCCFbits.IOCCF0 = 0
#define N64_IO_ISR_Enable()         PIE0bits.IOCIE = 1
#define N64_IO_ISR_Disable()        PIE0bits.IOCIE = 0
#define N64_IO_ISR_Routine(){\
    N64_IO_ISR_ClearFlag();\
    n64_rx_bit[n64_bitCount++] = N64_PORT;\
}
#define N64_IO_SetDigitalInput()    TRISCbits.TRISC0 = 1
#define N64_IO_SetDigitalOutput()   TRISCbits.TRISC0 = 0
#endif // _16F18446

#ifdef _16F18326
/* MachiKania Type M PIC16F18326
 * Clock: 32MHz
 * N64 Signal: RC5
 * Timer: TMR3 180us
 */

#define N64_LAT N64IO_LAT
#define N64_PORT N64IO_PORT
#define N64_PORT_BANK 

#define N64_TMR_Start() {PIR3bits.TMR3IF=0;TMR3_StartTimer();}
#define N64_TMR_Stop() TMR3_StartTimer()
#define N64_TMR_Reload() TMR3_Reload()
#define N64_TMR_HasOverflowOccured() TMR3_HasOverflowOccured()

#define N64_IO_ISR_ClearFlag()      IOCCFbits.IOCCF5 = 0;
#define N64_IO_ISR_Enable()         PIE0bits.IOCIE = 1
#define N64_IO_ISR_Disable()        PIE0bits.IOCIE = 0
#define N64_IO_ISR_Routine(){\
    N64_IO_ISR_ClearFlag();\
    n64_rx_bit[n64_bitCount++] = N64_PORT;\
}
#define N64_IO_SetDigitalInput()    TRISCbits.TRISC5 = 1
#define N64_IO_SetDigitalOutput()   TRISCbits.TRISC5 = 0
#endif // _16F18326

#define N64_IO_SetOutputMode() {\
    N64_IO_ISR_Disable();\
    N64_LAT = 1;\
    N64_IO_SetDigitalOutput();\
}
#define N64_IO_SetInputMode() {\
    N64_IO_SetDigitalInput();\
    N64_IO_ISR_ClearFlag();\
    N64_IO_ISR_Enable();\
}

#if _XTAL_FREQ == 16000000
    // CLK16MHz: 250nsec/cycle
#define N64_bit_0() {\
    N64_LAT = 0;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    N64_LAT = 1;\
    NOP();NOP();\
}
#define N64_bit_1() {\
    N64_LAT = 0;\
    NOP();NOP();\
    N64_LAT = 1;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
}
#define N64_bit_stop() {\
    N64_LAT = 0;\
    NOP();NOP();\
    N64_LAT = 1;\
}
#endif // _XTAL_FREQ == 16000000

#if _XTAL_FREQ == 32000000
// CLK32MHz: 125nsec/cycle
// 0: 3us 1: 1us
#define N64_bit_0() {\
    N64_LAT = 0;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    N64_LAT = 1;\
    NOP();NOP();\
    NOP();NOP();\
    NOP();NOP();\
}
// 0: 1us 1: 3us
#define N64_bit_1() {\
    N64_LAT = 0;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    N64_LAT = 1;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    NOP();NOP();NOP();NOP();\
}
#define N64_bit_stop() {\
    N64_LAT = 0;\
    NOP();NOP();\
    NOP();NOP();NOP();NOP();\
    N64_LAT = 1;\
}
#endif // _XTAL_FREQ == 32000000

#define N64IO_0() {N64_bit_0();N64_bit_0();N64_bit_0();N64_bit_0();}
#define N64IO_1() {N64_bit_0();N64_bit_0();N64_bit_0();N64_bit_1();}
#define N64IO_2() {N64_bit_0();N64_bit_0();N64_bit_1();N64_bit_0();}
#define N64IO_3() {N64_bit_0();N64_bit_0();N64_bit_1();N64_bit_1();}
#define N64IO_4() {N64_bit_0();N64_bit_1();N64_bit_0();N64_bit_0();}
#define N64IO_5() {N64_bit_0();N64_bit_1();N64_bit_0();N64_bit_1();}
#define N64IO_6() {N64_bit_0();N64_bit_1();N64_bit_1();N64_bit_0();}
#define N64IO_7() {N64_bit_0();N64_bit_1();N64_bit_1();N64_bit_1();}
#define N64IO_8() {N64_bit_1();N64_bit_0();N64_bit_0();N64_bit_0();}
#define N64IO_9() {N64_bit_1();N64_bit_0();N64_bit_0();N64_bit_1();}
#define N64IO_A() {N64_bit_1();N64_bit_0();N64_bit_1();N64_bit_0();}
#define N64IO_B() {N64_bit_1();N64_bit_0();N64_bit_1();N64_bit_1();}
#define N64IO_C() {N64_bit_1();N64_bit_1();N64_bit_0();N64_bit_0();}
#define N64IO_D() {N64_bit_1();N64_bit_1();N64_bit_0();N64_bit_1();}
#define N64IO_E() {N64_bit_1();N64_bit_1();N64_bit_1();N64_bit_0();}
#define N64IO_F() {N64_bit_1();N64_bit_1();N64_bit_1();N64_bit_1();}

// Identify
// send 0b0000_0000s
// return 25bit 0x050001s
#define N64IO_SendByte_0x00() {N64IO_0();N64IO_0();N64_bit_stop();}
// Status
// send 0b0000_0001s
// return 33bit Joystick btnS + XY-axis
#define N64IO_SendByte_0x01() {N64IO_0();N64IO_1();N64_bit_stop();}
// Read
// send 0b0000_0002s
#define N64IO_SendByte_0x02() {N64IO_0();N64IO_2();N64_bit_stop();}
// Write
// send 0b0000_0011s
#define N64IO_SendByte_0x03() {N64IO_0();N64IO_3();N64_bit_stop();}
// Reset
// send 0b1111_1111s
#define N64IO_SendByte_0xFF() {N64IO_F();N64IO_F();N64_bit_stop();}

typedef enum {
    // 1st byte
    N64_KEY_A = 0,
    N64_KEY_B,
    N64_KEY_Z,
    N64_KEY_START,
    N64_KEY_UP,
    N64_KEY_DOWN,
    N64_KEY_LEFT,
    N64_KEY_RIGHT,
    // 2nd byte
    N64_KEY_RSV8,
    N64_KEY_RSV9,
    N64_KEY_L,
    N64_KEY_R,
    N64_KEY_C_UP,
    N64_KEY_C_DOWN,
    N64_KEY_C_LEFT,
    N64_KEY_C_RIGHT,
    // 3rd byte
    // X Axis 8bit            
    N64_X_AXIS7,
    N64_X_AXIS6,
    N64_X_AXIS5,
    N64_X_AXIS4,
    N64_X_AXIS3,
    N64_X_AXIS2,
    N64_X_AXIS1,
    N64_X_AXIS0,
    // 4th byte
    // Y Axis 8bit            
    N64_Y_AXIS7,
    N64_Y_AXIS6,
    N64_Y_AXIS5,
    N64_Y_AXIS4,
    N64_Y_AXIS3,
    N64_Y_AXIS2,
    N64_Y_AXIS1,
    N64_Y_AXIS0,
    // Stop bit            
    N64_STOP_BIT,
} N64_KEYS_BIT;

#define N64_MAX_STAT_LEN (33)
#define N64_MAX_ID_LEN (25)
N64_PORT_BANK volatile uint8_t n64_bitCount;
N64_PORT_BANK uint8_t n64_rx_bit[ N64_MAX_STAT_LEN ];
uint8_t n64_rxdata[ (N64_MAX_STAT_LEN + 7) / 8 ];

enum {
    n64_cold = 0,
    n64_hot,
    n64_timeoutErr = -1,
} n64_stat;

int8_t n64ctrl_readIdentify(void);
int8_t n64ctrl_readStatus(void);

#ifdef	__cplusplus
}
#endif

#endif	/* N64_CTRL_H */
