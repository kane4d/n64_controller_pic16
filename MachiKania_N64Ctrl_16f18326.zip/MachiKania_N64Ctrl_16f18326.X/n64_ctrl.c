/* 
 * File:   n64_ctrl.c
 * Author: kane4d
 *
 * Created on September 21, 2018, 9:02 PM
 */

#include "n64_ctrl.h"

int8_t n64ctrl_readIdentify(void) {
    // n64_rx_bit[]
    // n64_bitCount
    int8_t ret = 0;
    N64_TMR_Reload(); // 170us
    N64_TMR_Start();
    n64_bitCount = 0;
    N64_IO_SetOutputMode();
    N64IO_SendByte_0x00();
    N64_IO_SetInputMode();
    while (1) {
        // __delay_us(5);
        if (n64_bitCount >= N64_MAX_ID_LEN) {
            N64_IO_ISR_Disable();
            ret = n64_bitCount;
            break;
        }
        if (N64_TMR_HasOverflowOccured()) { // timeout
            N64_IO_ISR_Disable();
            if (n64_bitCount == 0)
                ret = n64_timeoutErr;
            else
                ret = n64_timeoutErr * n64_bitCount;
            break;
        }
    }
    N64_TMR_Stop();
    return ret;
}

int8_t n64ctrl_readStatus(void) {
    // n64_rx_bit[]
    // n64_bitCount
    int8_t ret = 0;
    N64_TMR_Reload(); // 170us
    N64_TMR_Start();
    n64_bitCount = 0;
    N64_IO_SetOutputMode();
    N64IO_SendByte_0x01();
    N64_IO_SetInputMode();
    while (1) {
        // __delay_us(5);
        if (n64_bitCount >= N64_MAX_STAT_LEN) {
            N64_IO_ISR_Disable();
            ret = n64_bitCount;
            break;
        }
        if (N64_TMR_HasOverflowOccured()) { // timeout
            N64_IO_ISR_Disable();
            if (n64_bitCount >= N64_MAX_STAT_LEN) {
                ret = n64_bitCount;
                break;
            }
            if (n64_bitCount == 0)
                ret = n64_timeoutErr;
            else
                ret = n64_timeoutErr * n64_bitCount;
            break;
        }
    }
    N64_TMR_Stop();
    return ret;
}
