/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65.2
        Device            :  PIC16F18326
        Driver Version    :  2.00
 */

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
 */

#include "mcc_generated_files/mcc.h"
#include "n64_ctrl.h"

uint8_t g_SerialOutMode = 0;

void mk_joypad(void) {
    if (n64_rx_bit[N64_KEY_A] || n64_rx_bit[N64_KEY_B] || n64_rx_bit[N64_KEY_Z])
        KEY_FIRE_SetLow();
    else
        KEY_FIRE_SetHigh();
    if (n64_rx_bit[N64_KEY_START])
        KEY_START_SetLow();
    else
        KEY_START_SetHigh();
    if (n64_rx_bit[N64_KEY_UP] || n64_rx_bit[N64_KEY_C_UP])
        KEY_UP_SetLow();
    else
        KEY_UP_SetHigh();
    if (n64_rx_bit[N64_KEY_DOWN] || n64_rx_bit[N64_KEY_C_DOWN])
        KEY_DOWN_SetLow();
    else
        KEY_DOWN_SetHigh();
    if (n64_rx_bit[N64_KEY_LEFT] || n64_rx_bit[N64_KEY_C_LEFT])
        KEY_LEFT_SetLow();
    else
        KEY_LEFT_SetHigh();
    if (n64_rx_bit[N64_KEY_RIGHT] || n64_rx_bit[N64_KEY_C_RIGHT])
        KEY_RIGHT_SetLow();
    else
        KEY_RIGHT_SetHigh();

    // check serial out mode
    // L + C-Left:  serial out ON
    if (n64_rx_bit[N64_KEY_L] && n64_rx_bit[N64_KEY_C_LEFT])
        g_SerialOutMode = 1;
    // R + C-Right: serial out OFF
    if (n64_rx_bit[N64_KEY_R] && n64_rx_bit[N64_KEY_C_RIGHT])
        g_SerialOutMode = 0;
}

void b2b(void) {
    n64_rxdata[0] = n64_rxdata[1] = n64_rxdata[2] = n64_rxdata[3] = 0;
    for (uint8_t i = 0; i < 8; i++) {
        if (n64_rx_bit[i + N64_KEY_A]) n64_rxdata[0] |= 1 << (7 - i);
        if (n64_rx_bit[i + N64_KEY_RSV8]) n64_rxdata[1] |= 1 << (7 - i);
        if (n64_rx_bit[i + N64_X_AXIS7]) n64_rxdata[2] |= 1 << (7 - i);
        if (n64_rx_bit[i + N64_Y_AXIS7]) n64_rxdata[3] |= 1 << (7 - i);
    }
}

void mk_tx_joypad(void) {
    b2b();
    xprintf("%02x,%02x,%02x,%02x\n", n64_rxdata[0], n64_rxdata[1], n64_rxdata[2], n64_rxdata[3]);
}

void mk_tx_help(void) {
    // 
    xprintf("N64 Controller for MachiKania Type M\n");
    xprintf("Serial out ON:  L + C-Left\n");
    xprintf("Serial out Off: R + C-Right\n");
}

/*
                         Main application
 */
void main(void) {
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    xdev_out(EUSART_Write);
    int8_t ret;
    uint8_t i;
    while (1) {
        ret = n64ctrl_readIdentify();
        if (ret >= N64_MAX_ID_LEN) {
            __delay_ms(10);
            while (1) {
                ret = n64ctrl_readStatus();
                if (ret >= N64_MAX_STAT_LEN) {
                    // succeed
                    mk_joypad();
                    if (g_SerialOutMode) {
                        mk_tx_joypad();
                    }
                } else if (ret == -1) {
                    // time out
                    // no connection
                    __delay_ms(100);
                    break;
                } else if (ret < 0) {
                    // timeout
                    // noise or bit error
                    // retry after 10ms
                    __delay_ms(10);
                    //break;
                } else {
                    // bit length error
                    __delay_ms(100);
                    break;
                }
                __delay_ms(10);
            } // end while
        } else {
            //xprintf("Timeout Ident: %d", ret);
            __delay_ms(500);
        }
    }
}
/**
 End of File
 */